module.exports = {
  created: function(file) {
    return "Created: " + file;
  },
  modified: function(file) {
    return "Modified: " + file;
  }
};